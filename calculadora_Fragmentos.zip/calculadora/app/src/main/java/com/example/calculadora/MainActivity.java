package com.example.calculadora;


import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button btnAbrir;
    private int bo = 0; //con esta variable controlo si el fragment ya esta abierto o no

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //setContentView(R.layout.activity_main_dinamico); //fragmento (dinámica)
        setContentView(R.layout.activity_main_estatico); //fragmento (estática)



        CalculadoraFragmento fragment = new CalculadoraFragmento();

        btnAbrir = (Button) findViewById(R.id.btnAbrir);

        btnAbrir.setOnClickListener(b -> {
            if(bo==0){
                bo = getSupportFragmentManager().beginTransaction().add(R.id.contenedor,fragment).commit();
            }else{
                getSupportFragmentManager().beginTransaction().remove(fragment).commit();
                bo = 0;
            }
        });

    }
}